from src.Signal import Signal
from src.pipeline import get_periods

from bycycle.features import compute_features
import numpy as np

class ThetaSignal(Signal):
    def __init__(self, array: np.ndarray, sampling_rate: int, phasic=None, tonic=None):
        super().__init__(array, sampling_rate)
        
        self.phasic = phasic
        self.tonic = tonic
    
    def segment_cycles(self, f_theta, skip_threshold, threshold_kwargs):

        # Run Cycle by Cycle algorithm for burst detection
        df = compute_features(self.filtered, 
                              self.sampling_rate, 
                              f_range=f_theta, 
                              threshold_kwargs=threshold_kwargs, 
                              center_extrema='peak')
        
        df = df[["sample_last_trough", "sample_next_trough", "is_burst"]]
        phasic_df = df[df["is_burst"] == True]
        tonic_df = df[df["is_burst"] == False]

        result_msg = "{} periods in the {} signal: {}"
        print(result_msg.format("Phasic", self.filter_type, len(phasic_df)))
        print(result_msg.format("Tonic", self.filter_type, len(tonic_df)))
    
        self.phasic = get_periods(phasic_df[["sample_last_trough", "sample_next_trough"]], 
                                  skip_threshold=skip_threshold)
        self.tonic = get_periods(tonic_df[["sample_last_trough", "sample_next_trough"]],
                                 skip_threshold=skip_threshold)

    def get_phasic(self):
        segments = []
        for period in self.phasic:
            start, end = period
            segments.append(self.filtered[start:end])
        return segments
    
    def get_tonic(self):
        segments = []
        for period in self.tonic:
            start, end = period
            segments.append(self.filtered[start:end])
        return segments